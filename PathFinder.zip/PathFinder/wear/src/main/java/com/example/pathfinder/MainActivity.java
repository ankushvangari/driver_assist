package com.example.pathfinder;

import android.app.Activity;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;

public class MainActivity extends WearableActivity {

    private ImageButton walkButton, bikeButton, go;
    private String mode;
    private TextView question, answer;
    private Button plus, minus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mode = "walking";

        question = findViewById(R.id.textView);
        answer = findViewById(R.id.textView2);
        plus = findViewById(R.id.buttonPlus);
        plus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                updateAnswer(0.5);
            }
        });

        minus = findViewById(R.id.buttonMinus);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateAnswer(-0.5);
            }
        });

        walkButton = findViewById(R.id.imageButtonWalk);
        walkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View view = findViewById(R.id.boxInsetLayout);
                mode = "walking";
                question.setText("How many miles would you like to run/walk?");
                view.setBackgroundColor(getResources().getColor(R.color.blue));
            }
        });

        bikeButton = findViewById(R.id.imageButtonBike);
        bikeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                View view = findViewById(R.id.boxInsetLayout);
                mode = "biking";
                question.setText("How many miles would you like to bike?");
                view.setBackgroundColor(getResources().getColor(R.color.grey));
            }
        });

        go = findViewById(R.id.imageButtonGo);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double R = 6378.1;

                LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
                Location location = new Location("dummy provider");
                try{
                    location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                }catch(SecurityException e){
                    Toast.makeText(getApplicationContext(), "Please enable your location services in Settings.", Toast.LENGTH_LONG);
                    finish();
                }

                double longitude = location.getLongitude() * Math.PI/180;
                double latitude = location.getLatitude() * Math.PI/180;

                double distance = Double.parseDouble(answer.getText().toString()) * 1.60934/9;

                Random rand = new Random();
                double angle = rand.nextDouble() * Math.PI;

                double longitude1 = longitude + Math.atan2(Math.sin(angle)*Math.sin(distance/R)*Math.cos(latitude), Math.cos(distance/R)-Math.sin(latitude)*Math.sin(latitude));
                double latitude1 = Math.asin(Math.sin(latitude)*Math.cos(distance/R) + Math.cos(latitude)*Math.sin(distance/R)*(angle));

                angle += 1;
                if(angle > 2*Math.PI){
                    angle-=2*Math.PI;
                }

                double longitude2 = longitude + Math.atan2(Math.sin(angle)*Math.sin(distance/R)*Math.cos(latitude), Math.cos(distance/R)-Math.sin(latitude)*Math.sin(latitude));
                double latitude2 = Math.asin(Math.sin(latitude)*Math.cos(distance/R) + Math.cos(latitude)*Math.sin(distance/R)*(angle));

                longitude *= 180/Math.PI;
                latitude *= 180/Math.PI;
                longitude1 *= 180/Math.PI;
                latitude1 *= 180/Math.PI;
                longitude2 *= 180/Math.PI;
                latitude2 *= 180/Math.PI;


                String link = "https://www.google.com/maps/dir/?api=1&" +
                        "origin=" + Double.toString(latitude) + "," + Double.toString(longitude) +
                        "&destination=" + Double.toString(latitude) + "," + Double.toString(longitude) +
                        "&waypoints=" + Double.toString(latitude1) + "," + Double.toString(longitude1) + "|" +
                            Double.toString(latitude2) + "," + Double.toString(longitude2) +
                        "&key=AIzaSyAMuvUu1DLYyrQE1u5Y9xV5mZ_zTgzyrGw" +
                        "&travelmode=" + mode;

                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                startActivity(myIntent);
            }
        });
        // Enables Always-on
        setAmbientEnabled();
    }

    void updateAnswer(double i){
        double num = Double.parseDouble(answer.getText().toString());
        num+=i;
        answer.setText(Double.toString(num));
    }
}


